# Exit ---------------------------------------------------------------
observe({
    if (isTRUE(input$mainpage == "exit")) {
    stopApp()
  }
})
